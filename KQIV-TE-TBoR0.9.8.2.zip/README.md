# KQIV:TBoR
King’s Quest IV: The Breasts of Rosella

## warning v0.9.8 breaks all previous version save games

BETA release version 0.9.8.2 - moved overlays into resource.004, this is a new file that needs to be copied for the mod to work.
Content rating: Mature, 18+ for violence and strong sexual themes.

Developed using <a href="http://scicompanion.com/">SCI Companion</a>

This mod requires a full version of the DOS SCI game KQIV to work.

INSTALLATION

Easy method: Copy all the files into your KQIV game folder and run the game in DosBox or SCUMMVM. At minimum, replace resouce.001, resource.004 and resource.map for the mod to work.


FEATURES

Breasts - Two of them in fact!

Secret puzzles/ending - A brand new hidden side quest and ending.

Cameos - Characters, items, music and locations from other SCI0 games.

Multiple solutions and hidden skips - Complete original KQ4 puzzles exactly as intended, albeit with dialog changes, or explore all new playthrough options and dimension-bending content. Nearly all the additions are optional.

<a href="https://github.com/Doomlazer/KQIV-TBoR/wiki">Wiki (walkthrough)</a>

## Progress

nearing completion