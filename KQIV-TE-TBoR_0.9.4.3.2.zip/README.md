# KQIV:TE:TBoR
King’s Quest IV: Topless Edition: The Breasts of Rosella

BETA release version 0.9.4.3.2 
Content rating: Mature, 18+ for violence and strong sexual themes.


FEATURES: 

Breasts. Two of them in fact! 

Secret puzzles/ending - A brand new hidden side quest and ending!

Cameos. Characters, items, music and locations from other SCI0 games have been added.

Fully compatible with original puzzle solutions. The mod still allows you to complete the game exactly as originally intended. In-game dialog and story have been changed though.

Quality of life changes. The whale's tongue is extremely easy to climb now, you can KNOCK to get out of Lolotte's cell early because the timer was extended from 60 to 120 seconds, fewer shark attacks, more frequent whale encouters, 
GET BALL instead of LOOK UNDER BRIDGE, EAT FROG, as well as other minor adjustments including alternate puzzle solutions. 
0.9.4+: Troll attack chance per room reduced from 50% to 30%, dwarf eating scene reduced from 60 to 20 seconds.
	
https://github.com/Doomlazer/KQIV-TE-TBoR