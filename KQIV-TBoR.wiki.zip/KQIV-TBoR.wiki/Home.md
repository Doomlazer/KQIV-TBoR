# Welcome to the KQIV:TBoR wiki!

## WARNING SPOILERS

[Secret Quest/Ending Walkthrough](https://github.com/Doomlazer/KQIV-TE-TBoR/wiki/Mod-Secret-Ending-Walkthrough)

[Alternate Puzzle Solutions, Skips & Secrets](https://github.com/Doomlazer/KQIV-TE-TBoR/wiki/Alternate-Puzzle-Solutions,-Skips-and-Secrets)

[Quality of Life Change list](https://github.com/Doomlazer/KQIV-TE-TBoR/wiki/Quality-of-Life-Changes)

[Easter Eggs](https://github.com/Doomlazer/KQIV-TE-TBoR/wiki/Easter-Eggs)

