### Expanded Night

Several puzzles which were impossible to do at night can now be done at any time. Genesta's island, Orge's house, Dwarves house & Mine, Haunted Mansion can be entered at night (HH without the scarab). This accommodates more sequence breaks. 

### EAT FROG:

Eat the frog prince instead of KISS FROG or GET CROWN


### SHOW BREASTS:

Fisherman - Gives fishing pole

Minstrel - Gives lute

Dwarves - Hurry up soup eating

Three Witches - Briefly argue.

### SHOOT BOW:

More arrows can be purchased from the bartender (@ witch cave w/ tooth) for 200 score points each.

Alternate way to kill Sonny Bonds.

Kills the Cave Troll, but forces a new "bad" ending when giving the talisman to Genesta.

### OPEN SESAME:

Opens the secret door in the haunted house from anywhere in the room.

### SKIPS:

Talking to Roger in Lolotte's cell offers the player Golden Bridle.

Having the Monolith Burger Decoder Ring, the peacock feather, and the Tooth in Rosella's inventory will allow the player to receive up to six inventory items from TALK ROGER. [these skips are not fully tested yet].

EAT FROG with Tooth in inventory will make it night unusually early.

A Hairpin can be found in Marie's kitchen. This can be used to unlock Lolotte's bedroom door.

### TOOTH IN INVENTORY DIFFERENCES:

Organ plays World's-0-Wonder theme.

Waterfall >> Marie's house.

Witch's Skull >> SQ1 Bar (WIP).

Larry @ Genesta's room.

Rosella quotes the Maude theme song when mounting the unicorn.

Shark plays Jaws theme from KQ4SCI Floppy version.

Most of the main over world backgrounds are replaced by their floppy disk counterpart.

One in five chance Cedric replaces the crow flying overhead in the forest region.

Rosella can optionally walk to the castle on her own by choosing 'Kill Goons'.

Fishing from the pier without bait has a random chance to catch & release fish for score points/items. 

### FISH:

Boot or 'Not Biting': 0 points, chance: 10% (50% if Dead Fish inv. item hasn't been caught.)

Red Snapper: 5 points, chance: 40%

Slightly different color Red Snapper: 10 points, chance: 20%

Orange Snapper: 69 points, chance: 10%

Rainbow Fish: 239 points, chance: 7% 

Golden Fish: 1,000 points, chance: 6%

Mystery box: chance 4%, prize pool: [frog, toy horse, medal, locket, gold coins, baby rattle, 200-2000 random points] - If the player already has the randomly selected prize, points are awarded instead.

### CONDOM:

At the start of each game a number between 1 and 3 is randomly chosen which places the condom in two different bedrooms. When picked up in one room, it disappears from the other. The three possible locations are: [Fisherman's shack, Haunted House master bedroom], [Dwarves' bedroom, Lolotte's bedroom], [Ogre bedroom, Edgar's bedroom]

### HAIRPIN:

If it hasn't been picked up yet the hairpin will be noticed under Genesta's bed during Larry's sequence. It can also be found under the haunted house bed. It allows Rosella to unlock the door in Genesta's castle with the computer. It also allows her to open Lolotte's bedroom door early.

### COMPUTER PASSWORDS:

Surveillance: secret

Genesta: geoff

Bookkeeping: money