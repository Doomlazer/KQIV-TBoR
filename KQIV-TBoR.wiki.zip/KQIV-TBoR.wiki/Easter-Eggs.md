
### KQIV:TE:TBoR includes my standalone AGI easter egg port

## EGGS

### PIRATE 

Typing PIRATE at the copy protection prompt displays one of two random images, plays a few bars of drunken sailor and accuses the player of being a pirate before exiting the game. In the AGI version you needed to press ALT-D at the copy protection promt to enter the debugger, then type Pirate.  

### RAP KQ

During the end game sequence returning to the cell and typing RAP KQ in the center of the room will make Rosella brakedance to some complaints by the developers about 'berta. Notice with this patch the first visit to the cell has SCI graphics. Normally, during the SCI endgame, when opening the door you get the following message barring you from entering the room: 

<code>You wouldn't really want to visit your old cell, would you?</code>

This patch allows you to OPEN DOOR from the hallway and enter an AGI version of the cell with slightly differnt text messages. It copies Rosella's brakedancing animations cel for cel from the AGI CGA graphics. Though, don't expect 100% accuracy here. 

### BEAM ME

Type BEAM ME in the hallway outside Lolotte's cell during the final castle sequence. The warps you to a room with some developers.

## New TBoR Easter Eggs

Occasionally in the forest region, Cedric will replace Lolotte's raven. There is an even smaller chance Cedric will be carrying King Graham's head.

OPEN SEASAME will open the secret door in the haunted house from anywhere in the room.

Type GRITHER in the dwarves' kitchen. SAVE FIRST!