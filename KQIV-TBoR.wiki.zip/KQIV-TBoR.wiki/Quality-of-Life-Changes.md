Whale's tongue is trivial to climb. 

Most stairs will no longer kill you. You can still die from the ocean cliff and in the organ room if approaching the steps from the right-hand side.

KNOCK to get out of Lolotte's cell early (timer extended from 60 to 120 seconds. 

KNOCK while in the Ogre's closet to force him home early.

SHOW BREASTS to the dwarves to skip the 60 seconds of soup eating.

Reduced shark attack frequency. 

Increased whale encounter frequency. 

Optionally GET BALL instead of LOOK UNDER BRIDGE.

Cave Troll chance per room reduced from 50% to 30%.

LIFT LATCH without the painting's approval.

