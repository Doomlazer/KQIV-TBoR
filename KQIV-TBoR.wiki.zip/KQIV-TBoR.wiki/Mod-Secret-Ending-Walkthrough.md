# WARNING: SPOILERS

# Shortest path to complete Mod ending as of v0.9.9 (not yet tagged):

## Intro/Get tooth:

From start, GO NORTH, GET RING, travel to Lolotte's Castle Cell, KISS ROGER, LOOK HOLE (optional), GET TOOTH. 



## Sonny Bonds:

LOOK UNDER BED in the Haunted house master bedroom to get the hairpin. USE HAIRPIN on the 1st floor door in Genesta's Castle, USE COMPUTER, PRESS BUTTON, CD WORK, CD SURVEILLANCE, SECRET, then read the file for SONNY BONDS.

Travel to the bridge, GET BALL, go north to the pond, THROW BALL, GET FROG, KISS FROG, go to the waterfall, with tooth in inventory WEAR CROWN, enter Marie's house, TALK MAN, choose 'Deceive', GET CASE.



## Larry Laffer: 

At the start of each game a number between 1 and 3 is randomly chosen which places the condom in two different bedrooms. When picked up in one room, it disappears from the other. The three possible locations are: [Fisherman's shack, Haunted House master bedroom], [Dwarves' bedroom, Lolotte's bedroom], [Ogre bedroom, Edgar's bedroom]. Locate and GET CONDOM.

With the Tooth in inventory, travel to Genesta's room, GIVE CONDOM. KISS LARRY.


## Fisherman's Wife:

GET SHOVEL from inside the haunted house. At anytime before giving the Fisherman's the diamond pouch, SHOW BREASTS while inside his shanty, leave and walk a few screens away, travel behind the Fisherman's shack and DIG GRAVE, GET SKULL. 



## END GAME: 

Behind the kitchen in the Haunted House is a room with a pedestal (if you have the tooth), PUT TOOTH, walk to the pot in the room, PUT MONEY [IN POT], PUT LOVE, PUT DEATH, YELL SRP3, KILL SELF.

The tooth must be in the pedestal to deposit items in the pot.

How do you discover the phrase to yell? READ NOTE with the tooth and decoder in Rosella's inventory to display the decoded instructions. Without the tooth READ NOTE randomly displays two minor hints for the mod in addition to Sierra's ads.
